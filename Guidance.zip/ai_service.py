# ai_service.py
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/ai', methods=['POST'])
def ai_reply():
    data = request.get_json()
    user_message = data.get('message', '')
    
    # Simple echo AI stub
    reply = f"AI response to: {user_message}"
    
    return jsonify({"reply": reply})

if __name__ == '__main__':
    app.run(port=5000)
